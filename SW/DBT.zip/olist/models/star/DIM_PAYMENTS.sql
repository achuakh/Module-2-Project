SELECT
    order_id as payment_sid,
    payment_sequential,
    payment_type,
    payment_installments,
    payment_value
FROM {{ source('Olist_csv', 'olist_order_payments') }}