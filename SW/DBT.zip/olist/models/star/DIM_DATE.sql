SELECT
    0 as date_sid
FROM {{ source('Olist_csv', 'olist_customers') }}