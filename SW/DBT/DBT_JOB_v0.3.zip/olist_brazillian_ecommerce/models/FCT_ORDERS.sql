WITH payment AS (
  SELECT order_id, SUM(payment_value) AS total_payment
  FROM {{ source('olist_brazilian_ecommerce', 'public_order_payments') }}
  GROUP BY order_id
),
order_items AS (
  SELECT order_id, 
  SUM(price) order_amt, 
  SUM(freight_value) as freight_amt, 
  SUM(price) + sum(freight_value) as total_order_amt_wf_freight
  FROM {{ source('olist_brazilian_ecommerce', 'public_order_items') }}
  GROUP BY order_id
)
SELECT 
  o.order_id AS pk_order_id, 
  o.order_id AS pk_item_sid, 
  o.order_id AS fk_payment_sid, 
  o.order_id AS fk_review_sid,  
  o.customer_id AS fk_customer_sid, 
  FORMAT_DATE('%Y%m%d', CAST(order_purchase_timestamp AS DATE)) AS fk_order_purchased_date_sid,
  FORMAT_DATE('%Y%m%d', CAST(order_approved_at AS DATE)) AS fk_order_approved_at_date_sid,
  FORMAT_DATE('%Y%m%d', CAST(order_delivered_carrier_date AS DATE)) AS fk_order_delivered_carrier_date_sid,
  FORMAT_DATE('%Y%m%d', CAST(order_delivered_customer_date AS DATE)) AS fk_order_delivered_customer_date_sid,
  FORMAT_DATE('%Y%m%d', CAST(order_estimated_delivery_date AS DATE)) AS fk_order_estimated_delivery_date_sid, 
  o.order_status, 
  p.total_payment,
  i.order_amt,
  i.freight_amt,
  i.total_order_amt_wf_freight, 
  i.total_order_amt_wf_freight - p.total_payment as balance_amt, 
  CASE 
    WHEN i.total_order_amt_wf_freight - p.total_payment = 0 THEN 'COMPLETED'
    WHEN i.total_order_amt_wf_freight - p.total_payment < 0 THEN 'COMPLETED'
    WHEN i.total_order_amt_wf_freight - p.total_payment > 0 THEN 'IN PROGRESS'
    ELSE 'NOT APPLICABLE'
  END AS payment_status,
  o.order_purchase_timestamp, 
  SAFE.TIMESTAMP(o.order_approved_at) AS order_approved_at_ts,
  SAFE.TIMESTAMP(o.order_delivered_carrier_date) AS order_delivered_carrier_date_ts,
  SAFE.TIMESTAMP(o.order_delivered_customer_date) AS order_delivered_customer_date_ts,
  o.order_estimated_delivery_date,
  FORMAT_TIMESTAMP('%Y-%m-%d %I:%M:%S %p', CURRENT_TIMESTAMP()) AS load_date
FROM {{ source('olist_brazilian_ecommerce', 'public_orders') }} o
LEFT JOIN payment p ON o.order_id = p.order_id
LEFT JOIN order_items i ON o.order_id = i.order_id 
