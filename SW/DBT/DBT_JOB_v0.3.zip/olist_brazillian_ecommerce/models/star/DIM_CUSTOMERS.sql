SELECT
    customer_id as pk_customer_sid,
    customer_unique_id,
    customer_zip_code_prefix,
    customer_city,
    customer_state,
    FORMAT_TIMESTAMP('%Y-%m-%d %I:%M:%S %p', CURRENT_TIMESTAMP()) AS load_date
FROM {{ source('olist_brazilian_ecommerce', 'public_customers') }}
