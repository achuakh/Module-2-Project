SELECT 
order_id AS fk_payment_sid, 
order_id AS fk_review_sid,  
order_id AS fk_item_sid, 
customer_id AS fk_customer_sid, 
FORMAT_DATE('%Y%m%d', order_purchase_timestamp) AS fk_order_purchased_date_sid, 
FORMAT_DATE('%Y%m%d', order_approved_at) AS fk_order_approved_at_date_sid, 
FORMAT_DATE('%Y%m%d', order_delivered_carrier_date) AS fk_order_delivered_carrier_date_sid, 
FORMAT_DATE('%Y%m%d', order_delivered_customer_date) AS fk_order_delivered_customer_date_sid, 
FORMAT_DATE('%Y%m%d', order_estimated_delivery_date) AS fk_order_estimated_delivery_date_sid, 
order_id AS pk_order_id, 
order_status, 
order_purchase_timestamp, 
order_approved_at, 
order_delivered_carrier_date, 
order_delivered_customer_date, 
order_estimated_delivery_date,
FORMAT_TIMESTAMP('%Y-%m-%d %I:%M:%S %p', CURRENT_TIMESTAMP()) AS load_date
FROM {{ source('Olist_csv', 'olist_orders') }}
