SELECT
    order_id as pk_payment_sid,
    payment_sequential as pk_payment_sequential,
    payment_type,
    payment_installments,
    payment_value,
    FORMAT_TIMESTAMP('%Y-%m-%d %I:%M:%S %p', CURRENT_TIMESTAMP()) AS load_date
FROM {{ source('Olist_csv', 'olist_order_payments') }}
